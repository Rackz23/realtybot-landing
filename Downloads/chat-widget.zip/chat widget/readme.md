# Apexestate solutions Chat Widget

**How to install**  
1. Unzip this folder.  
2. Copy the contents of `widget.html` into the `<body>` of *your* website (wherever you want the bot to appear).  
3. Ensure the `<script type="module" src="…landbot-3.0.0.mjs">` line stays in the `<head>` or before the `<div>`.  
4. Save and publish—your chat widget will now load on your site!
